package com.austin.bookclub.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.austin.bookclub.models.Book;
import com.austin.bookclub.services.BookService;
import com.austin.bookclub.services.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/books")
public class BooksController {

    private static final String REDIRECT_TO_BOOKS = "redirect:/books";

    private final BookService bookService;

    public BooksController(BookService bookService) {
        this.bookService = bookService;
    }
    @Autowired
    public UserService userService;

    //? Handler for displaying the list of ALL books
    @GetMapping
    public String index(Model model, HttpSession httpSession) {
        if (httpSession.getAttribute("user_id") == null) {
            return "redirect:/users/login/register";

        }
        model.addAttribute("user", userService.getUser((Long) httpSession.getAttribute("user_id")));
        model.addAttribute("books", bookService.allBooks());
        return "/books/index.jsp";
    }

    //? Handler for displaying details of ONE book
    @GetMapping("/{bookId}")
    public String getOne(Model model, @PathVariable("bookId") Long bookId) {
        model.addAttribute("book", bookService.getOne(bookId));
        model.addAttribute("books", bookService.allBooks());
        return "index.jsp";
    }

    //? Handler for CREATING a new book
    @PostMapping
    public String create(@Valid @ModelAttribute("book") Book book, BindingResult result) {
        if (result.hasErrors()) {
            return "/books/new.jsp";
        }
        bookService.createBook(book);
        return REDIRECT_TO_BOOKS;
    }

    //? Handler for displaying the form to ADD a new book
    @GetMapping("/new")
    public String newBook(@ModelAttribute("book") Book book) {
        return "/books/new.jsp";
    }

    //? Handler for displaying the form to EDIT an existing book
    @GetMapping("/{bookId}/edit")
    public String edit(@PathVariable("bookId") Long bookId, Model model) {
        model.addAttribute("book", bookService.getOne(bookId));
        return "/books/edit.jsp";
    }

    //? Handler for UPDATING an existing book's details
    @PutMapping("/{bookId}")
    public String update(@Valid @ModelAttribute("book") Book book, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("book", book);
            return "/books/edit.jsp";
        }
        bookService.updateBook(book);
        return REDIRECT_TO_BOOKS;
    }

    //? Handler for DELETING a book
    @PostMapping("/{bookId}/delete")
    public String destroy(@PathVariable("bookId") Long bookId) {
        bookService.deleteBook(bookId);
        return REDIRECT_TO_BOOKS;
    }
}
