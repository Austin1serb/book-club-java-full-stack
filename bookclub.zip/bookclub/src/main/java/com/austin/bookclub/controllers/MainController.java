package com.austin.bookclub.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.austin.bookclub.services.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String dashboard(HttpSession session, Model model) {

        model.addAttribute("loginUser", userService.getUser((Long) session.getAttribute("user_id")));
        return "redirect:books";
    }

}
